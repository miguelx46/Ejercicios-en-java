/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package algoritmo_punto_y_fama;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author migue
 */
public class Algoritmo_punto_y_fama {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random r = new Random();
        Scanner l = new Scanner(System.in);
        int numran, digran1, digran2, digran3, digran4, numjug, digjug1, digjug2, digjug3, digjug4, f, p;
        f = 0;
        p = 0;
        // esto generará un número que sea un valor de 0 hasta 8999
        numran = r.nextInt(9000);
        numran = numran + 1000;
        // se mostrara el número generado y los digitos solo en el desarrollo del algoritmo
        // para determinar sí lo que se quiere hacer es correcto       
        digran1 = numran / 1000;
        System.out.println("El primer digito es: " + digran1);
        digran2 = numran % 1000;
        digran2 = digran2 / 100;
        System.out.println("El segundo digito es: " + digran2);
        digran3 = numran % 1000;
        digran3 = digran3 % 100;
        digran3 = digran3 / 10;
        System.out.println("El tercer digito es: " + digran3);
        digran4 = numran % 10;
        System.out.println("El cuarto digito es: " + digran4);
        // validando que el número generado no tenga ningún digito repetido
        while (digran1 == digran2 || digran1 == digran3 || digran1 == digran4 || digran2 == digran3 || digran2 == digran4 || digran4 == digran3) {
            System.out.println("El número generado es: " + numran);
            System.out.println("Tiene digitos iguales...");
            numran = r.nextInt(9000);
            numran = numran + 1000;
            digran1 = numran / 1000;
            digran2 = numran % 1000;
            digran2 = digran2 / 100;
            digran3 = numran % 1000;
            digran3 = digran3 % 100;
            digran3 = digran3 / 10;
            digran4 = numran % 10;
        }

        System.out.println("Se ha roto el while!,la validación funciono");
        System.out.println("El número generado es: " + numran);
        System.out.println("Se ha generado un número de 4 cifras, adivina cual es.. ");
        //varaible f para mantener funcionando el while y seguir digitando números hasta que se adivine el número
        while (f != 4) {
            // para ir mostrando las famas y puntos
            System.out.println("Famas: " + f + " Puntos: " + p);
            System.out.println("Digita un número de 4 cifras:");
            numjug = l.nextInt();
            //digitos del número ingresado por el jugador
            digjug1 = numjug / 1000;
            System.out.println("Primer digito: " + digjug1);
            digjug2 = numjug % 1000;
            digjug2 = digjug2 / 100;
            System.out.println("Segundo digito: " + digjug2);
            digjug3 = numjug % 1000;
            digjug3 = digjug3 % 100;
            digjug3 = digjug3 / 10;
            System.out.println("Tercero digito: " + digjug3);
            digjug4 = numjug % 10;
            System.out.println("Cuarto digito: " + digjug4);
            //validando los digitos del jugador
            while (numjug < 1000 || numjug > 9999 & digjug1 == digjug2 || digjug1 == digjug3 || digjug1 == digjug4 || digjug2 == digjug3 || digjug2 == digjug4 || digjug4 == digjug3) {
                System.out.println("Famas: " + f + " Puntos: " + p);
                System.out.println("El número ingresado no es valido, ingrese un número de 4 cifras y que no tenga digitos repetidos:");
                System.out.println("Primer digito: " + digjug1);
                System.out.println("Segundo digito: " + digjug2);
                System.out.println("Tercero digito: " + digjug3);
                System.out.println("Cuarto digito: " + digjug4);
                numjug = l.nextInt();
            }
            
            //el caso en que ninguno de los digitos está en la posición correcta
            if (digjug1 != digran1 & digjug2 != digran2 & digjug3 != digran3 & digjug4 != digran4) {
                f = 0;
            }
            //casos en que 1 de los digitos está en la posición correcta
            if (digjug1 != digran1 & digjug2 != digran2 & digjug3 != digran3 & digjug4 == digran4) {
                f = 1;
            }
            if (digjug1 != digran1 & digjug2 != digran2 & digjug3 == digran3 & digjug4 != digran4) {
                f = 1;
            }
            if (digjug1 != digran1 & digjug2 == digran2 & digjug3 != digran3 & digjug4 != digran4) {
                f = 1;
            }
            if (digjug1 != digran1 & digjug2 != digran2 & digjug3 != digran3 & digjug4 == digran4) {
                f = 1;
            }
            //casos en que 2 de los digitos está en la posición correcta
            
            //casos en que 3 de los digitos está en la posición correcta
            
            //if para terminar el algoritmo si el jugador introduce el número correcto
            if (numran == numjug) {
                System.out.println("¡Felicidades, has encontrado el número! el cuál es: " + numran);
                f = 4;
            }
        }
    }

}
